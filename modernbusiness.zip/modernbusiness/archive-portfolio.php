<?php get_header(); // load header ?>

<?php get_footer(); // load footer ?>
